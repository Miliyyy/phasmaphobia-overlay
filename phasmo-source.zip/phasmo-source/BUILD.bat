@echo off
title Phasmo Journal - Build EXE
color 0A
cls

echo.
echo  ============================================================
echo   PHASMO JOURNAL - ONE-TIME EXE BUILDER
echo  ============================================================
echo.

:: ── Find real Python (skip the fake Microsoft Store one) ────────────
set PYTHON=

:: Check all known locations, most specific first
for %%P in (
    "%LOCALAPPDATA%\Python\bin\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    "C:\Python313\python.exe"
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "C:\Python310\python.exe"
    "C:\Program Files\Python313\python.exe"
    "C:\Program Files\Python312\python.exe"
    "C:\Program Files\Python311\python.exe"
) do (
    if exist %%P (
        if "%PYTHON%"=="" set PYTHON=%%P
    )
)

:: Also try python on PATH but skip the fake WindowsApps one
if "%PYTHON%"=="" (
    for /f "delims=" %%i in ('where python 2^>nul') do (
        echo %%i | find /i "WindowsApps" >nul || (
            if "%PYTHON%"=="" set PYTHON=%%i
        )
    )
)

if "%PYTHON%"=="" (
    echo.
    echo  ERROR: Could not find a real Python installation.
    echo.
    echo  Please install Python from: https://www.python.org/downloads/
    echo  Check "Add Python to PATH" during install, then run this again.
    echo.
    pause
    exit /b 1
)

echo  [1/4] Found Python: %PYTHON%
echo.

:: Verify it actually works
%PYTHON% --version >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Found Python path but it does not run correctly.
    echo  Path: %PYTHON%
    echo  Try reinstalling Python from python.org
    pause
    exit /b 1
)

:: Show version
echo  Python version:
%PYTHON% --version
echo.

:: ── Install PyInstaller ─────────────────────────────────────────────
echo  [2/4] Installing PyInstaller and keyboard...
echo  (Needs internet, ~30 seconds)
echo.
%PYTHON% -m pip install pyinstaller keyboard --quiet --upgrade
if errorlevel 1 (
    echo.
    echo  ERROR: pip install failed. Check your internet connection.
    pause
    exit /b 1
)
echo  Installed OK.
echo.

:: ── Build ───────────────────────────────────────────────────────────
echo  [3/4] Building EXE... (30-60 seconds, please wait)
echo.

%PYTHON% -m PyInstaller ^
    --onefile ^
    --windowed ^
    --name "PhasmoJournal" ^
    --clean ^
    --noconfirm ^
    "%~dp0phasmo_journal.pyw"

:: ── Result ──────────────────────────────────────────────────────────
echo.
if exist "%~dp0dist\PhasmoJournal.exe" (
    echo  [4/4] Copying to this folder...
    copy "%~dp0dist\PhasmoJournal.exe" "%~dp0PhasmoJournal.exe" >nul 2>&1

    :: Clean up build junk
    if exist "%~dp0dist"  rmdir /s /q "%~dp0dist"  >nul 2>&1
    if exist "%~dp0build" rmdir /s /q "%~dp0build" >nul 2>&1
    if exist "%~dp0PhasmoJournal.spec" del "%~dp0PhasmoJournal.spec" >nul 2>&1

    echo.
    echo  ============================================================
    echo   SUCCESS!
    echo  ============================================================
    echo.
    echo   PhasmoJournal.exe is ready in this folder.
    echo   Double-click it to launch. No Python needed ever again.
    echo.
    echo   Saved rounds stored at:
    echo   %APPDATA%\PhasmoJournal\phasmo_rounds.json
    echo  ============================================================
    echo.
) else (
    echo  ============================================================
    echo   BUILD FAILED
    echo  ============================================================
    echo.
    echo  Most common fix: temporarily disable your antivirus,
    echo  then run BUILD.bat again.
    echo.
    echo  Also make sure phasmo_journal.pyw is in the same folder.
    echo  ============================================================
)

pause
