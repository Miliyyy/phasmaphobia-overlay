@echo off
:: Launches Phasmo Journal in OBS mode
:: In OBS mode the window has a normal title bar so OBS can capture it
:: as a Window Capture source

set PYTHON=
for %%P in (
    "%LOCALAPPDATA%\Python\bin\pythonw.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\pythonw.exe"
    "%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe"
    "%LOCALAPPDATA%\Programs\Python\Python310\pythonw.exe"
) do (
    if exist %%P if "%PYTHON%"=="" set PYTHON=%%P
)
if "%PYTHON%"=="" (
    for /f "delims=" %%i in ('where pythonw 2^>nul') do (
        echo %%i | find /i "WindowsApps" >nul || if "%PYTHON%"=="" set PYTHON=%%i
    )
)
if "%PYTHON%"=="" set PYTHON=pythonw

start "" %PYTHON% "%~dp0phasmo_journal.pyw" --obs
