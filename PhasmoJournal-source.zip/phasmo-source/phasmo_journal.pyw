"""
Phasmo Journal Overlay - v4
External always-on-top overlay. No injection. No memory reading.
- No white title bar (overrideredirect)
- Mousewheel scrolls anywhere
- Speed shows ranges
- Global hotkeys via keyboard lib (works while game is focused)
"""
import tkinter as tk
import time, threading, json, os, sys
from datetime import datetime

# ── Windows ───────────────────────────────────────────────────────────────────
try:
    import ctypes, ctypes.wintypes
    _u32 = ctypes.windll.user32
    WINDOWS = True
except Exception:
    WINDOWS = False

# ── Palette ───────────────────────────────────────────────────────────────────
BG      = '#080b0f'
BG2     = '#0d1117'
BG3     = '#060e18'
BORDER  = '#1e3a5f'
ACCENT  = '#4a9eff'
SUCCESS = '#44ff88'
DANGER  = '#ff4444'
WARN    = '#ffaa00'
PURPLE  = '#cc88ff'
TEXT    = '#c8ddf0'
TEXT2   = '#7a9ab8'
TEXT3   = '#3a5a78'
MUTED   = '#4a6080'

EVIDENCE = [
    ('emf',      'EMF Level 5'),
    ('spirit',   'Spirit Box'),
    ('orb',      'Ghost Orb'),
    ('ultra',    'Ultraviolet'),
    ('freezing', 'Freezing Temps'),
    ('writing',  'Ghost Writing'),
    ('dots',     'DOTS Projector'),
]

GHOSTS = [
    dict(name='Spirit',      ev=['emf','spirit','writing'],
         hunt='50% sanity · 1.7 m/s · 25s cooldown',
         speed='1.7 m/s (constant — no modifiers)',
         speed_lo=1.7, speed_hi=1.7,
         str_='No unique strength — most average ghost.',
         weak='Smudge sticks last 180s (3× longer than normal).',
         tell='Almost impossible to confirm by behaviour alone. Smudge duration is the only test.',
         unique='After smudging: if it does NOT re-hunt for 3 full minutes → Spirit.'),
    dict(name='Wraith',      ev=['emf','spirit','dots'],
         hunt='50% sanity · 1.7 m/s · can teleport to players',
         speed='1.7 m/s (teleports, no salt footprints)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Teleports to random players. Leaves NO UV footprints in salt.',
         weak='Stepping in salt triggers EMF 2 — no footprint visible.',
         tell='Salt disturbed + no UV print = Wraith. Appears beside you silently.',
         unique='Salt trap: disturbed salt with zero UV footprints → Wraith confirmed.'),
    dict(name='Phantom',     ev=['spirit','ultra','dots'],
         hunt='50% sanity · 1.7 m/s · turns invisible mid-hunt',
         speed='1.7 m/s (goes invisible mid-hunt, reappears elsewhere)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Slow blink rate during manifestations. Drains sanity fast when visible.',
         weak='Photographing it makes it turn invisible temporarily.',
         tell='Absent from photos. Slow blink every 1–2s vs 0.3–1s normal.',
         unique='Photo test: ghost not in photo after taking it → Phantom.'),
    dict(name='Poltergeist', ev=['spirit','ultra','writing'],
         hunt='50% sanity · 1.7 m/s · no movement modifier',
         speed='1.7 m/s (constant)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Throws 5+ objects simultaneously in one burst. 2% sanity per object.',
         weak='Powerless in rooms with no throwable items.',
         tell='Mass object throw (5+ items at once) is unique to Poltergeist.',
         unique='See 5+ items fly at the same moment → Poltergeist confirmed.'),
    dict(name='Banshee',     ev=['ultra','orb','dots'],
         hunt='50% of TARGET\'s sanity · 1.7 m/s · target-locked',
         speed='1.7 m/s (always chases its ONE chosen target only)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Picks one target and ONLY hunts that player — ignores everyone else.',
         weak='Crucifix works at 5m range (vs 3m). Unique wailing shriek on parabolic mic.',
         tell='Always follows its chosen victim even when others are closer.',
         unique='Parabolic mic shriek → Banshee. Watch which player it always chases.'),
    dict(name='Jinn',        ev=['emf','ultra','freezing'],
         hunt='50% sanity · 1.7–2.5 m/s · fuse box dependent',
         speed='1.7 m/s close  |  2.5 m/s when >3m away AND fuse box ON',
         speed_lo=1.7, speed_hi=2.5,
         str_='2.5 m/s from range when fuse box is powered. EMF spike near breaker.',
         weak='Turn off fuse box → speed ability completely disabled.',
         tell='Very fast approach from distance, slows near you.',
         unique='Turn off fuse box — if it slows significantly → Jinn confirmed.'),
    dict(name='Mare',        ev=['spirit','orb','writing'],
         hunt='60% dark / 40% lit · 1.7 m/s',
         speed='1.7 m/s (constant — uses darkness as weapon)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Hunts at 60% sanity in darkness vs 40% with lights on.',
         weak='Keep lights ON — drops hunt threshold to 40%.',
         tell='Turns lights off constantly. Much more aggressive in dark rooms.',
         unique='Keep lights on at all times. Hunts quickly only in darkness → Mare.'),
    dict(name='Revenant',    ev=['orb','writing','freezing'],
         hunt='50% sanity · 1.0 m/s (no LOS) → 3.0 m/s (LOS)',
         speed='1.0 m/s no line-of-sight  |  3.0 m/s with line-of-sight',
         speed_lo=1.0, speed_hi=3.0,
         str_='3.0 m/s — fastest ghost when it sees you. Biggest speed swing.',
         weak='Only 1.0 m/s when not chasing. HIDE immediately.',
         tell='Crawls while searching → rockets when it spots you.',
         unique='Very slow → suddenly explosive when it sees you → Revenant. Hide!'),
    dict(name='Shade',       ev=['emf','writing','freezing'],
         hunt='35% sanity (low!) · 1.7 m/s · won\'t hunt near groups',
         speed='1.7 m/s (constant)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Won\'t hunt if multiple players nearby. Very shy and low activity.',
         weak='Hunt threshold 35% — can surprise you very early.',
         tell='Near-zero activity with team. Very active when alone.',
         unique='Send one player alone — if ghost activates only then → Shade.'),
    dict(name='Demon',       ev=['ultra','writing','freezing'],
         hunt='ANY sanity · 1.7 m/s · 20s cooldown (shortest)',
         speed='1.7 m/s (constant — can hunt at 100% sanity!)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Can hunt at 100% sanity. Shortest cooldown (20s vs 25s).',
         weak='Crucifix range 5m. Ouija board free vs Demon.',
         tell='Hunts unexpectedly early at very high sanity.',
         unique='Hunts at 80%+ sanity → Demon. Place 2 crucifixes immediately.'),
    dict(name='Yurei',       ev=['orb','freezing','dots'],
         hunt='50% sanity · 1.7 m/s · sanity drain aura',
         speed='1.7 m/s (constant)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Strong sanity drain aura. Unique FULL door-close animation.',
         weak='Smudge its room — traps it there for 60 seconds.',
         tell='Doors fully slam shut (complete close). Sanity drops faster than expected.',
         unique='Full door-close animation (not partial swing) → Yurei.'),
    dict(name='Oni',         ev=['emf','freezing','dots'],
         hunt='50% sanity · 1.7 m/s · very high activity',
         speed='1.7 m/s (constant)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Extremely active near players. Hard object throws. Never appears as shadow.',
         weak='High activity makes it easier to find.',
         tell='Hard throws across full room. Never shadowy — always full visible form.',
         unique='Constant EMF + DOTS + hard throws → Oni. Photo won\'t vanish.'),
    dict(name='Yokai',       ev=['spirit','orb','dots'],
         hunt='50% normal / 80% with talking · 1.7 m/s',
         speed='1.7 m/s (only 2m equipment detect range during hunts)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Triggered by nearby talking — threshold rises to 80% with voices.',
         weak='Only 2m equipment detection during hunts (vs 9m normal).',
         tell='Hunts fast when players are talking. Calmer when silent.',
         unique='Hunts rapidly during team chatter → Yokai. Stay silent.'),
    dict(name='Hantu',       ev=['ultra','orb','freezing'],
         hunt='50% sanity · 1.4–2.7 m/s (temperature)',
         speed='1.4 m/s warm rooms  |  2.7 m/s freezing rooms',
         speed_lo=1.4, speed_hi=2.7,
         str_='Speed scales with temperature — up to 2.7 m/s in freezing rooms.',
         weak='Turn off fuse box to warm the map — slows it dramatically.',
         tell='Visible frozen breath during hunt even OUTSIDE ghost room.',
         unique='Frozen breath outside ghost room → Hantu. Kill power to warm.'),
    dict(name='Goryo',       ev=['emf','ultra','dots'],
         hunt='50% sanity · 1.7 m/s · very room-bound',
         speed='1.7 m/s (constant)',
         speed_lo=1.7, speed_hi=1.7,
         str_='DOTS silhouette only visible on camera when no players are in the room.',
         weak='Rarely strays more than one room from its favourite spot.',
         tell='DOTS never shows in person — only visible on video camera feed.',
         unique='DOTS on camera but never live → Goryo confirmed.'),
    dict(name='Myling',      ev=['emf','ultra','writing'],
         hunt='50% sanity · 1.7 m/s · SILENT approach',
         speed='1.7 m/s (footsteps inaudible until 12m away)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Near-silent during hunts. Equipment barely glitches until 12m away.',
         weak='More frequent paranormal sounds on parabolic mic.',
         tell='Can\'t hear footsteps or equipment until very close.',
         unique='Silent hunt + frequent parabolic sounds → Myling. Very dangerous.'),
    dict(name='Gloom',       ev=['spirit','orb','writing'],
         hunt='50% sanity · 1.7 m/s · group sanity drain',
         speed='1.7 m/s (constant)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Drains sanity of ALL nearby players simultaneously.',
         weak='Using sanity pills near it triggers surge of activity.',
         tell='Team sanity drops very fast without direct contact.',
         unique='Use sanity pills near ghost — immediate activity surge → Gloom.'),
    dict(name='Twins',       ev=['emf','spirit','freezing'],
         hunt='50% sanity · 1.5–1.9 m/s (two entities)',
         speed='Main twin 1.9 m/s  |  Decoy twin 1.5 m/s',
         speed_lo=1.5, speed_hi=1.9,
         str_='Two entities — either can start a hunt. Inconsistent speed.',
         weak='Interacts in two different locations near-simultaneously.',
         tell='EMF/interactions in two separate rooms at nearly the same time.',
         unique='Double interactions in distant rooms at once → Twins.'),
    dict(name='Raiju',       ev=['emf','orb','dots'],
         hunt='50% normal / 65% near electronics · 1.7–2.5 m/s',
         speed='1.7 m/s base  |  2.5 m/s near active electronics',
         speed_lo=1.7, speed_hi=2.5,
         str_='2.5 m/s when near active electronic equipment during hunts.',
         weak='Causes more equipment disruption — easier to locate.',
         tell='Noticeably faster near cameras, spirit box, tripods.',
         unique='Fast near active gear → slow without it → Raiju. Turn off ALL gear.'),
    dict(name='Obake',       ev=['emf','ultra','orb'],
         hunt='50% sanity · 1.7 m/s · shapeshifts mid-hunt',
         speed='1.7 m/s (shapeshifts to another ghost model during hunt)',
         speed_lo=1.7, speed_hi=1.7,
         str_='Fingerprints disappear after 60s. Can leave unique 6-fingered print.',
         weak='Shapeshifts to another ghost model — very visible mid-hunt.',
         tell='6-finger UV print is UNIQUE to Obake. Model changes mid-hunt.',
         unique='UV on switch: 6 fingers = confirmed Obake.'),
    dict(name='Mimic',       ev=['spirit','ultra','freezing'],
         hunt='Copies current ghost\'s threshold and speed',
         speed='Variable — copies whichever ghost it is currently mimicking',
         speed_lo=0.4, speed_hi=3.0,
         str_='Copies ANY ghost\'s full behaviour, abilities and speed.',
         weak='ALWAYS produces Ghost Orb as false 4th evidence.',
         tell='Completely inconsistent behaviour — seems like different ghosts.',
         unique='Ghost Orb + 3 Mimic evidences → confirmed Mimic.'),
    dict(name='Moroi',       ev=['spirit','writing','freezing'],
         hunt='50% sanity · 1.5–2.25 m/s (sanity dependent)',
         speed='1.5 m/s at 100% sanity  |  2.25 m/s at 0% sanity',
         speed_lo=1.5, speed_hi=2.25,
         str_='Gets faster as YOUR sanity drops. Curses via Spirit Box.',
         weak='Smudge sticks blind it for 12s (vs 6s normal).',
         tell='Seems to accelerate over the investigation.',
         unique='Getting visibly faster as game goes on → Moroi. Keep sanity HIGH.'),
    dict(name='Deogen',      ev=['spirit','writing','dots'],
         hunt='40% sanity · 0.4–3.0 m/s',
         speed='3.0 m/s from range  |  0.4 m/s right next to target',
         speed_lo=0.4, speed_hi=3.0,
         str_='Always knows your exact location. Hiding is useless.',
         weak='Slows to 0.4 m/s right next to you. Sprint in circles.',
         tell='Heavy breathing when nearby. Rockets toward you then nearly stops.',
         unique='Fast from range → nearly stops up close → Deogen. Circle it.'),
    dict(name='Thaye',       ev=['orb','writing','dots'],
         hunt='75% young → 15% aged · 2.75→1.0 m/s',
         speed='2.75 m/s young  |  ~1.0 m/s fully aged',
         speed_lo=1.0, speed_hi=2.75,
         str_='Young: extremely fast (2.75 m/s). Slows dramatically over time.',
         weak='Ouija board interactions age it faster.',
         tell='Very fast/aggressive first 5 mins. Noticeably slower 10+ mins in.',
         unique='Extremely fast early then visibly slows → Thaye. Use Ouija to age it.'),
]

MAPS = [
    dict(name='6 Tanglewood Drive',   size='Small',  floors=1, exits=1,
         rooms='7 rooms', ghost='Living Room, Bedroom, Garage, Bathroom, Kitchen',
         hiding='Bedroom wardrobe · Garage cabinet',
         tips=['Smallest map. Ghost room confirmed in under 2 minutes.',
               'Single floor, no vertical confusion. One exit — always know your escape.',
               'Crucifix in the hallway covers almost every ghost spawn area.',
               'Ghost reaches you FAST. Pre-identify hiding spot before investigating.',
               'Attic hatch exists — check it last if ground floor rooms are warm.']),
    dict(name='10 Ridgeview Court',   size='Small',  floors=2, exits=1,
         rooms='9 rooms', ghost='Basement (most common), Master Bedroom, Living Room',
         hiding='Upstairs wardrobe · Basement locker',
         tips=['Check the BASEMENT first — most frequent ghost spawn here.',
               'Staircase is a deadly chokepoint. Never get caught on it mid-hunt.',
               'Only 1 exit. Basement ghost = long sprint to safety. Know the path.',
               'Upstairs locker near master bedroom is the most reliable hiding spot.',
               'Breath fog visible in cold rooms — can find ghost room without thermometer.']),
    dict(name='Edgefield Street',     size='Small',  floors=2, exits=1,
         rooms='9 rooms', ghost='Basement, Kids Room, Master Bedroom, Living Room',
         hiding='Upstairs closet · Under stairs area',
         tips=['Basement is a very frequent spawn — check it first.',
               'Children\'s room upstairs has unusually high ghost activity.',
               'Single entrance — coordinate team so nobody blocks the door.',
               'Narrow hallways make looping very difficult — always find a closet first.']),
    dict(name='Bleasdale Farmhouse',  size='Small',  floors=2, exits=1,
         rooms='10 rooms', ghost='Attic (very common), Bedroom, Living Room',
         hiding='Basement locker · Bedroom wardrobe',
         tips=['Attic is the most common ghost room — check it early.',
               'Attic has limited space and ONE exit. Don\'t get trapped up there.',
               'Locker in the lower level is the best hiding spot on this map.',
               'One exit means ghost can cut you off. Pre-plan escape before going solo.']),
    dict(name='Grafton Farmhouse',    size='Medium', floors=2, exits=2,
         rooms='12 rooms', ghost='Barn (any floor), Master Bedroom, Basement',
         hiding='Barn lockers · Bedroom wardrobe · Bathroom',
         tips=['Split the team — one group per floor for efficient sweep.',
               'Ghost room can be in barn OR main house — thermometer sweep both.',
               'Two exits give much better hunt escape options.',
               'Revenant is very dangerous here due to long corridors.']),
    dict(name='Camp Woodwind',        size='Small',  floors=1, exits=2,
         rooms='8 areas', ghost='Any tent or cabin',
         hiding='Cars · Toilet block · Tree clusters',
         tips=['OUTDOOR MAP: Sanity does NOT drain outdoors. Stay outside between runs!',
               'Ghost room is always inside a tent or cabin — quick sweep confirms it.',
               'Jinn is VERY dangerous here — disable the power box near cabins first.',
               'Open layout with 2 exits makes escaping hunts much easier.']),
    dict(name='Maple Lodge Campsite', size='Medium', floors=1, exits=2,
         rooms='11 areas', ghost='Any cabin or dock area',
         hiding='Parked cars · Toilet block · Dense trees',
         tips=['Outdoor campsite — outdoor areas fully protect sanity.',
               'Ghost roams widely. Stay together until ghost room confirmed.',
               'Dock ghost room: limited hiding spots — be careful near the water.',
               'Cabin rooms drop temperature fast — quick to find ghost room.']),
    dict(name='Prison',               size='Large',  floors=3, exits=2,
         rooms='20+ rooms', ghost='Cell blocks, Solitary confinement, Guard room',
         hiding='Individual cells (close door) · Guard booths',
         tips=['Massive 3-floor map. Split by cell block wings systematically.',
               'Solitary confinement is the most frequent ghost spawn.',
               'Sanity drops FAST in dark cells. Use sanity pills at 60%.',
               'Long corridors make Revenant and Deogen extremely deadly.',
               'Individual cells with door closed are valid hiding spots.']),
    dict(name='Willow Street House',  size='Medium', floors=2, exits=1,
         rooms='11 rooms', ghost='Upstairs bedrooms, Basement, Living room',
         hiding='Upstairs wardrobe · Basement corner · Bathroom',
         tips=['Ghost room most often upstairs — start thermometer sweep there.',
               'ONLY ONE EXIT. Never let the ghost cut you off from the front door.',
               'DOTS projector works very well in the narrow upstairs hallway.',
               'Medium size but single exit makes this more dangerous than it looks.']),
    dict(name='Brownstone High School',size='Medium',floors=3, exits=2,
         rooms='14 rooms', ghost='Boiler room (basement), Classrooms, Gym',
         hiding='Classroom closets (multiple per floor) · Bathrooms',
         tips=['Boiler room basement is the most frequent spawn — dark and cold.',
               'Three floors — sweep top to bottom with thermometer.',
               'Stairwells are dangerous chokepoints. Learn alternate routes.',
               'One of the best hiding maps — multiple closets per floor.']),
    dict(name='Sunny Meadows',        size='Large',  floors=2, exits=4,
         rooms='25+ rooms', ghost='Any wing (north/south/chapel/medical)',
         hiding='Lockers throughout · Bathroom stalls · Offices',
         tips=['LARGEST MAP. Full team coordination essential.',
               'Divide into 4 zones: north wing, south wing, ground, upper floor.',
               'Establish a central safe point near reception for regrouping.',
               'Chapel area is a very frequent ghost spawn — check it early.',
               'Parabolic mic is almost required. Four exits help enormously.']),
    dict(name='High School',          size='Large',  floors=2, exits=3,
         rooms='18 rooms', ghost='Science labs, Gym, Music room, Cafeteria',
         hiding='Classroom closets · Bathroom stalls',
         tips=['Long corridors can trap you. Always know which classroom to duck into.',
               'Ghost room often in science labs or gym — thermometer sweep first.',
               'Split team: one group per floor for efficient sweep.',
               'Cafeteria is large and open — hard to hide in but good for looping.']),
]

SPEED_REF = [
    ('Deogen (far) / Revenant (LOS)', 3.00, DANGER),
    ('Thaye (young)',                  2.75, '#ff5544'),
    ('Hantu (freezing room)',          2.70, '#ff7744'),
    ('Jinn (far + power on)',          2.50, '#ff8844'),
    ('Raiju (near electronics)',       2.50, '#ff8844'),
    ('Moroi (0% sanity)',              2.25, WARN),
    ('Twins — main',                   1.90, WARN),
    ('Standard (most ghosts)',         1.70, ACCENT),
    ('Moroi (100% sanity)',            1.50, '#44aaff'),
    ('Twins — decoy',                  1.50, '#44aaff'),
    ('Hantu (warm room)',              1.40, '#44bbff'),
    ('Thaye (fully aged)',             1.00, SUCCESS),
    ('Revenant (no LOS)',              1.00, SUCCESS),
    ('Deogen (near target)',           0.40, SUCCESS),
]

# ─────────────────────────────────────────────────────────────────────────────
class App:
    FN   = ('Consolas', 9)
    FN_S = ('Consolas', 8)
    FU   = ('Segoe UI', 10, 'bold')
    FU_S = ('Segoe UI', 9)

    def __init__(self):
        self.root = tk.Tk()
        # ── Remove OS title bar completely ──
        self.root.overrideredirect(True)
        self.root.configure(bg=BG)
        self.root.geometry('430x720+40+40')
        self.root.attributes('-topmost', True)
        self.root.attributes('-alpha', 0.93)
        self.root.minsize(300, 80)

        # state
        self.ev          = {k: None for k, _ in EVIDENCE}
        self.sel_ghost   = None
        self.ev_suspect  = None          # ghost name the player suspects
        self.ev_eliminated = set()       # manually crossed-out ghosts in ev tab
        self.sanity      = [75, 75, 75, 75]
        self.hunt_active = False
        self.hunt_start  = 0.0
        self.smudge_active = False
        self.smudge_start  = 0.0
        self.bpm_taps    = []
        self.bpm_cancel  = None
        self.los         = False
        self.tab         = 'evidence'
        self.map_idx     = 0
        self.opacities   = [0.93, 0.75, 0.50, 0.25]
        self.op_idx      = 0
        self._drag_x = self._drag_y = 0
        self.rounds = []           # list of saved round dicts
        self.journal_filter = ""   # search/filter string
        self.gh_favorites = set()  # favorited ghost names
        self.gh_sort = "match"     # match | alpha | fav
        self._load_rounds()

        self._build()
        self._tick()
        self._start_global_hotkeys()

    # ── drag (needed because overrideredirect removes OS drag) ────────
    def _drag_start(self, e):
        self._drag_x = e.x_root - self.root.winfo_x()
        self._drag_y = e.y_root - self.root.winfo_y()
    def _drag_move(self, e):
        self.root.geometry(f'+{e.x_root-self._drag_x}+{e.y_root-self._drag_y}')

    # ── build UI ──────────────────────────────────────────────────────
    def _build(self):
        # Custom title bar (replaces OS bar)
        tb = tk.Frame(self.root, bg='#0a1828', height=30)
        tb.pack(fill='x')
        tb.pack_propagate(False)
        tk.Label(tb, text='👻  PHASMO JOURNAL', bg='#0a1828',
                 fg=ACCENT, font=self.FN).pack(side='left', padx=8)
        for txt, cmd, col in [
            ('👁',  self._cycle_op,  TEXT2),
            ('▭',   self._compact,   TEXT2),
            ('✕',   self.root.quit,  DANGER),
            ('↺',   self._reset_all, WARN),
        ]:
            b = tk.Button(tb, text=txt, bg='#0a1828', fg=col, font=self.FN_S,
                          bd=0, padx=6, pady=0,
                          activebackground='#1a2840',
                          activeforeground=ACCENT, cursor='hand2',
                          command=cmd)
            b.pack(side='right', pady=4, padx=1)
        for w in [tb] + tb.winfo_children():
            if not isinstance(w, tk.Button):
                w.bind('<Button-1>', self._drag_start)
                w.bind('<B1-Motion>', self._drag_move)

        # Tab bar
        tabbar = tk.Frame(self.root, bg='#060e18', height=26)
        tabbar.pack(fill='x')
        tabbar.pack_propagate(False)
        self.tab_btns = {}
        for tid, lbl in [('evidence','Evidence'), ('ghosts','Ghosts'),
                          ('speed','Speed'),       ('maps','Maps'),
                          ('hunt','Hunt'),          ('notes','Notes'),
                          ('journal','Journal')]:
            b = tk.Label(tabbar, text=lbl.upper(), bg='#060e18', fg=MUTED,
                         font=self.FN_S, padx=7, pady=5, cursor='hand2')
            b.pack(side='left')
            b.bind('<Button-1>', lambda e, t=tid: self._switch(t))
            self.tab_btns[tid] = b

        # Pane host
        self.pane_host = tk.Frame(self.root, bg=BG)
        self.pane_host.pack(fill='both', expand=True)

        self.panes = {
            'evidence': self._pane_evidence(),
            'ghosts':   self._pane_ghosts(),
            'speed':    self._pane_speed(),
            'maps':     self._pane_maps(),
            'hunt':     self._pane_hunt(),
            'notes':    self._pane_notes(),
            'journal':  self._pane_journal(),
        }

        # Status bar
        sb = tk.Frame(self.root, bg='#050c14', height=18)
        sb.pack(fill='x')
        sb.pack_propagate(False)
        self.sb_lbl = tk.Label(sb, text='● LIVE | MATCHES: 24 | EV: 0/7',
                                bg='#050c14', fg=TEXT3, font=self.FN_S,
                                anchor='w', padx=8)
        self.sb_lbl.pack(fill='x')

        self._switch('evidence')

    # ── scrollable pane factory ───────────────────────────────────────
    def _scrollable(self, parent):
        outer  = tk.Frame(parent, bg=BG)
        canvas = tk.Canvas(outer, bg=BG, highlightthickness=0, bd=0)
        # No visible scrollbar — mousewheel only
        canvas.pack(fill='both', expand=True)
        inner = tk.Frame(canvas, bg=BG)
        win   = canvas.create_window((0, 0), window=inner, anchor='nw')

        def _resize(e):
            canvas.itemconfig(win, width=e.width)
        def _scroll(e):
            canvas.configure(scrollregion=canvas.bbox('all'))
        def _wheel(e):
            canvas.yview_scroll(int(-1 * (e.delta / 120)), 'units')

        canvas.bind('<Configure>', _resize)
        inner.bind('<Configure>',  _scroll)
        canvas.bind('<MouseWheel>', _wheel)
        inner.bind('<MouseWheel>',  _wheel)

        outer._canvas = canvas
        outer._wheel  = _wheel
        return outer, inner

    def _bind_scroll(self, widget, canvas_wheel):
        """Recursively bind mousewheel to every child widget."""
        widget.bind('<MouseWheel>', canvas_wheel)
        for child in widget.winfo_children():
            self._bind_scroll(child, canvas_wheel)

    # ── helpers ───────────────────────────────────────────────────────
    def _sec(self, parent, text):
        f = tk.Frame(parent, bg=BG)
        f.pack(fill='x', padx=8, pady=(6, 2))
        tk.Label(f, text=text, bg=BG, fg=TEXT3,
                 font=self.FN_S, anchor='w').pack(side='left')
        tk.Frame(f, bg=BORDER, height=1).pack(side='left', fill='x',
                                               expand=True, padx=(5, 0))

    def _card(self, parent, bg=BG3, border=BORDER):
        f = tk.Frame(parent, bg=bg,
                     highlightbackground=border, highlightthickness=1)
        f.pack(fill='x', padx=8, pady=2)
        return f

    def _btn(self, parent, text, cmd,
             bg=BG2, fg=TEXT2, border=BORDER, pady=8, font=None):
        b = tk.Button(parent, text=text, bg=bg, fg=fg,
                      font=font or self.FN_S,
                      bd=1, relief='flat',
                      highlightbackground=border, highlightthickness=1,
                      padx=8, pady=pady,
                      activebackground='#1a2840', activeforeground=ACCENT,
                      cursor='hand2', command=cmd)
        b.pack(fill='x', padx=8, pady=2)
        return b

    # ── EVIDENCE pane ─────────────────────────────────────────────────────
    def _pane_evidence(self):
        outer, inner = self._scrollable(self.pane_host)
        self._sec(inner, '1-CLICK = FOUND   ·   2-CLICKS = RULED OUT')
        self.ev_grid = tk.Frame(inner, bg=BG)
        self.ev_grid.pack(fill='x', padx=8, pady=(0, 4))
        self.ev_grid.columnconfigure(0, weight=1)
        self.ev_grid.columnconfigure(1, weight=1)
        self._render_ev_grid()

        # Save round — right after evidence, always visible
        self._sec(inner, 'SAVE THIS ROUND')
        save_row = tk.Frame(inner, bg=BG)
        save_row.pack(fill='x', padx=8, pady=(0, 6))
        self.round_name_var = tk.StringVar(value='')
        name_entry = tk.Entry(save_row, textvariable=self.round_name_var,
                              bg=BG2, fg=TEXT, font=self.FN_S,
                              insertbackground=ACCENT,
                              highlightbackground=BORDER, highlightthickness=1,
                              relief='flat', bd=0)
        name_entry.pack(side='left', fill='x', expand=True, ipady=7, padx=(0, 4))
        name_entry.insert(0, 'Round name...')
        name_entry.bind('<FocusIn>',
            lambda e: name_entry.delete(0, 'end')
            if name_entry.get() == 'Round name...' else None)
        tk.Button(save_row, text='SAVE  +',
                  bg='#0a1828', fg=ACCENT, font=self.FN_S,
                  bd=1, relief='flat',
                  highlightbackground=ACCENT, highlightthickness=1,
                  padx=12, pady=7, cursor='hand2',
                  command=self._save_round).pack(side='right')

        self._sec(inner, 'MATCHING GHOSTS')
        hint = tk.Frame(inner, bg='#090f1a',
                        highlightbackground=BORDER, highlightthickness=1)
        hint.pack(fill='x', padx=8, pady=(0, 4))
        tk.Label(hint, text=(
            'Left-click = mark as SUSPECT (yellow)\n'
            'Right-click = CROSS OUT ghost\n'
            'Click again = undo'
        ), bg='#090f1a', fg=TEXT3, font=self.FN_S,
           anchor='w', justify='left', padx=8, pady=5).pack(fill='x')
        self.match_frame = tk.Frame(inner, bg=BG)
        self.match_frame.pack(fill='x', padx=8, pady=(0, 8))
        return outer
    def _render_ev_grid(self):
        for w in self.ev_grid.winfo_children():
            w.destroy()
        for i, (eid, elabel) in enumerate(EVIDENCE):
            state = self.ev[eid]
            if state == 'found':
                bg, fg, bord = '#003a1a', SUCCESS, SUCCESS
            elif state == 'ruled':
                bg, fg, bord = '#2a0000', DANGER, DANGER
            else:
                bg, fg, bord = BG2, TEXT3, BORDER
            r, c = divmod(i, 2)
            btn = tk.Button(self.ev_grid, text=elabel,
                            bg=bg, fg=fg, font=self.FU_S,
                            bd=1, relief='flat',
                            highlightbackground=bord, highlightthickness=1,
                            padx=6, pady=8,
                            activebackground='#1a2840', cursor='hand2')
            btn.grid(row=r, column=c, padx=3, pady=3, sticky='ew')
            btn.bind('<Button-1>', lambda e, k=eid: self._ev_cycle(k))

    def _ev_cycle(self, k):
        cur = self.ev[k]
        if cur is None: self.ev[k] = 'found'
        elif cur == 'found': self.ev[k] = 'ruled'
        else: self.ev[k] = None
        self._refresh()
    def _ev_click(self, k):
        self.ev[k] = None if self.ev[k] == 'found' else 'found'
        self._refresh()
    def _ev_dbl(self, k):
        self.ev[k] = None if self.ev[k] == 'ruled' else 'ruled'
        self._refresh()

    # ── GHOSTS pane ───────────────────────────────────────────────────
    def _pane_ghosts(self):
        outer, inner = self._scrollable(self.pane_host)
        # Sort + legend row
        ctrl = tk.Frame(inner, bg=BG)
        ctrl.pack(fill='x', padx=8, pady=(6, 2))
        tk.Label(ctrl, text='SORT:', bg=BG, fg=TEXT3, font=self.FN_S).pack(side='left')
        self.gh_sort_btns = {}
        for sid, slbl in [('match','By match'), ('alpha','A-Z'), ('fav','Favorites')]:
            b = tk.Label(ctrl, text=slbl, bg=BG2, fg=TEXT2, font=self.FN_S,
                         padx=7, pady=3, cursor='hand2',
                         highlightbackground=BORDER, highlightthickness=1)
            b.pack(side='left', padx=2)
            b.bind('<Button-1>', lambda e, s=sid: self._gh_set_sort(s))
            self.gh_sort_btns[sid] = b
        tk.Label(ctrl, text='Right-click = options', bg=BG,
                 fg=TEXT3, font=self.FN_S).pack(side='right')
        self._sec(inner, 'ALL 24 GHOSTS  click=info  right-click=options')
        self.ghost_list = tk.Frame(inner, bg=BG)
        self.ghost_list.pack(fill='x', padx=8, pady=(0, 4))
        self._sec(inner, 'SELECTED GHOST')
        self.gh_detail = tk.Frame(inner, bg=BG3,
                                   highlightbackground=BORDER,
                                   highlightthickness=1)
        self.gh_detail.pack(fill='x', padx=8, pady=(0, 8))
        tk.Label(self.gh_detail,
                 text='Click any ghost above to see full info',
                 bg=BG3, fg=TEXT3, font=self.FU_S,
                 anchor='w', padx=8, pady=8).pack(fill='x')
        return outer

    def _render_ghost_list(self, frame, poss, clickable=True):
        """Build once, update in-place on selection — no flash."""
        sorted_g = self._gh_get_sorted(poss) if clickable else sorted(
            GHOSTS, key=lambda g: (0 if g in poss else 1, g['name']))
        current_order = [w._ghost_name for w in frame.winfo_children()
                         if hasattr(w, '_ghost_name')]
        new_order = [g['name'] for g in sorted_g]
        if current_order != new_order:
            for w in frame.winfo_children():
                w.destroy()
        existing = {w._ghost_name: w for w in frame.winfo_children()
                    if hasattr(w, '_ghost_name')}
        for g in sorted_g:
            ip     = g in poss
            isel   = g['name'] == self.sel_ghost and clickable
            itop   = ip and len(poss) == 1 and clickable
            is_fav = g['name'] in self.gh_favorites and clickable
            is_x   = not ip and not clickable
            if itop:
                bg, fg_n, bord = '#001a0a', SUCCESS, SUCCESS
            elif isel:
                bg, fg_n, bord = '#0a1828', ACCENT, ACCENT
            elif is_fav and ip:
                bg, fg_n, bord = '#14100a', WARN, '#553300'
            elif ip:
                bg, fg_n, bord = BG2, TEXT, BORDER
            elif is_x:
                bg, fg_n, bord = BG, '#2a3040', BG
            else:
                bg, fg_n, bord = BG, TEXT3, BG
            name_fnt = (self.FU_S[0], self.FU_S[1], 'overstrike') if is_x else self.FU_S

            if g['name'] in existing:
                # update colours only — no destroy — no flash
                row = existing[g['name']]
                row.config(bg=bg, highlightbackground=bord)
                kids = row.winfo_children()
                if kids:
                    kids[0].config(bg=bg, fg=fg_n, font=name_fnt)
                if len(kids) > 1:
                    kids[1].config(bg=bg)
                    for j, eid in enumerate(g['ev']):
                        st = self.ev[eid]
                        dc = SUCCESS if st=='found' else DANGER if st=='ruled' else BORDER
                        dots = kids[1].winfo_children()
                        if j < len(dots):
                            dots[j].config(bg=dc)
                continue

            # first build
            row = tk.Frame(frame, bg=bg,
                           highlightbackground=bord, highlightthickness=1)
            row._ghost_name = g['name']
            row.pack(fill='x', pady=1)
            lbl = tk.Label(row, text=g['name'], bg=bg, fg=fg_n,
                           font=name_fnt, anchor='w', padx=8, pady=5)
            lbl.pack(side='left')
            df = tk.Frame(row, bg=bg)
            df.pack(side='left')
            for eid in g['ev']:
                st = self.ev[eid]
                dc = SUCCESS if st=='found' else DANGER if st=='ruled' else BORDER
                tk.Frame(df, bg=dc, width=6, height=6).pack(side='left', padx=1, pady=8)
            lo, hi = g['speed_lo'], g['speed_hi']
            spd = f'{lo:.1f}' if lo == hi else f'{lo:.1f}-{hi:.1f}'
            sc = DANGER if hi >= 2.5 else WARN if hi >= 1.9 else ACCENT
            if itop:
                tk.Label(row, text='TOP', bg='#003a1a', fg=SUCCESS,
                         font=self.FN_S, padx=4).pack(side='right')
            if is_fav:
                tk.Label(row, text='★', bg=bg, fg=WARN,
                         font=self.FN_S, padx=2).pack(side='right')
            if ip and poss and clickable:
                tk.Label(row, text=f'{round(100/len(poss))}%',
                         bg=bg, fg=WARN, font=self.FN_S, padx=4).pack(side='right')
            tk.Label(row, text=f'{spd}m/s', bg=bg, fg=sc if ip else '#2a3040',
                     font=self.FN_S, padx=4).pack(side='right')
            if clickable:
                for w in [row, lbl, df]:
                    w.bind('<Button-1>', lambda e, n=g['name']: self._sel_ghost(n))
                    w.bind('<Button-3>', lambda e, n=g['name']: self._gh_context_menu(e, n))

    def _update_ghost_list_styles(self, poss):
        self._render_ghost_list(self.ghost_list, poss)
        self._render_ghost_detail(self.gh_detail, self.sel_ghost)
        self._update_sort_btns()

    def _update_sort_btns(self):
        if not hasattr(self, 'gh_sort_btns'):
            return
        for sid, btn in self.gh_sort_btns.items():
            btn.config(
                fg=(ACCENT if sid == self.gh_sort else TEXT2),
                bg=('#0a1828' if sid == self.gh_sort else BG2),
                highlightbackground=(ACCENT if sid == self.gh_sort else BORDER))

    def _gh_context_menu(self, event, name):
        menu = tk.Menu(self.root, tearoff=0, bg=BG2, fg=TEXT,
                       activebackground='#1a2840', activeforeground=ACCENT,
                       font=self.FN_S, bd=0, relief='flat')
        is_fav = name in self.gh_favorites
        menu.add_command(
            label=('★ Remove from favorites' if is_fav else '☆ Add to favorites'),
            command=lambda: self._gh_toggle_fav(name))
        menu.add_command(
            label='Set as SUSPECT this investigation',
            command=lambda: self._gh_set_suspect_from_tab(name))
        menu.add_separator()
        menu.add_command(
            label='Clear selection',
            command=lambda: self._sel_ghost(self.sel_ghost) if self.sel_ghost else None)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _gh_set_sort(self, s):
        self.gh_sort = s
        self._update_ghost_list_styles(self._possible())

    def _gh_get_sorted(self, poss):
        if self.gh_sort == 'alpha':
            return sorted(GHOSTS, key=lambda g: g['name'])
        elif self.gh_sort == 'fav':
            return sorted(GHOSTS, key=lambda g: (
                0 if g['name'] in self.gh_favorites else 1,
                0 if g in poss else 1,
                g['name']
            ))
        else:
            return sorted(GHOSTS, key=lambda g: (0 if g in poss else 1, g['name']))

    def _gh_toggle_fav(self, name):
        if name in self.gh_favorites:
            self.gh_favorites.discard(name)
        else:
            self.gh_favorites.add(name)
        self._update_ghost_list_styles(self._possible())

    def _gh_set_suspect_from_tab(self, name):
        self.ev_suspect = None if self.ev_suspect == name else name
        self._refresh()

    def _sel_ghost(self, name):
        self.sel_ghost = None if self.sel_ghost == name else name
        poss = self._possible()
        self._update_ghost_list_styles(poss)


    def _render_ev_ghost_list(self, frame, poss):
        """Ghost list for evidence tab: left-click=suspect, right-click=eliminate."""
        for w in frame.winfo_children():
            w.destroy()
        # Show possible ghosts first, then show manually eliminated ones at bottom
        all_display = list(poss) + [g for g in GHOSTS if g not in poss and g['name'] not in self.ev_eliminated]
        # Just show possible + any manually eliminated in one sorted list
        sorted_g = sorted(GHOSTS, key=lambda g: (0 if g in poss else 1, g['name']))
        for g in sorted_g:
            ip   = g in poss
            is_suspect  = g['name'] == self.ev_suspect
            is_elim     = g['name'] in self.ev_eliminated
            # styling
            if is_suspect and ip:
                bg, fg_n, bord = '#1a1400', WARN, WARN
            elif is_elim or not ip:
                bg, fg_n, bord = BG, '#2a3040', BG
            else:
                bg, fg_n, bord = BG2, TEXT, BORDER
            row = tk.Frame(frame, bg=bg, highlightbackground=bord, highlightthickness=1)
            row.pack(fill='x', pady=1)
            # Name with strikethrough if eliminated
            name_fnt = (self.FU_S[0], self.FU_S[1], 'overstrike') if (is_elim or not ip) else self.FU_S
            lbl = tk.Label(row, text=g['name'], bg=bg, fg=fg_n,
                           font=name_fnt, anchor='w', padx=8, pady=5)
            lbl.pack(side='left')
            # Evidence dots
            df = tk.Frame(row, bg=bg)
            df.pack(side='left')
            for eid in g['ev']:
                st = self.ev[eid]
                dc = SUCCESS if st=='found' else DANGER if st=='ruled' else BORDER
                tk.Frame(df, bg=dc, width=6, height=6).pack(side='left', padx=1, pady=8)
            # Right side: suspect badge or match %
            if is_suspect and ip:
                tk.Label(row, text='SUSPECT', bg='#1a1400', fg=WARN,
                         font=self.FN_S, padx=6).pack(side='right')
            elif is_elim:
                tk.Label(row, text='ruled out', bg=BG, fg='#332222',
                         font=self.FN_S, padx=6).pack(side='right')
            elif ip:
                tk.Label(row, text=f'{round(100/len(poss))}%', bg=bg, fg=WARN,
                         font=self.FN_S, padx=6).pack(side='right')
            # Speed
            lo, hi = g['speed_lo'], g['speed_hi']
            spd = f'{lo:.1f}' if lo==hi else f'{lo:.1f}-{hi:.1f}'
            sc = DANGER if hi >= 2.5 else WARN if hi >= 1.9 else ACCENT
            tk.Label(row, text=f'{spd}m/s', bg=bg, fg=sc if ip else '#2a3040',
                     font=self.FN_S, padx=4).pack(side='right')
            # Bindings: left-click = suspect, right-click = eliminate
            def _left(e, n=g['name']):
                if n in self.ev_eliminated:
                    return   # can't suspect an eliminated ghost
                self.ev_suspect = None if self.ev_suspect == n else n
                self._refresh()
            def _right(e, n=g['name']):
                if n in self.ev_eliminated:
                    self.ev_eliminated.discard(n)
                else:
                    self.ev_eliminated.add(n)
                    if self.ev_suspect == n:
                        self.ev_suspect = None
                self._refresh()
            for w in [row, lbl, df]:
                w.bind('<Button-1>', _left)
                w.bind('<Button-3>', _right)


    def _render_ghost_detail(self, container, ghost_name):
        for w in container.winfo_children():
            w.destroy()
        if not ghost_name:
            tk.Label(container,
                     text='← Click a ghost to see its full ability info',
                     bg=BG3, fg=TEXT3, font=self.FU_S,
                     anchor='w', padx=8, pady=8).pack(fill='x')
            return
        g = next((x for x in GHOSTS if x['name'] == ghost_name), None)
        if not g:
            return
        ev_names = [lbl for k, lbl in EVIDENCE if k in g['ev']]
        tk.Label(container, text=g['name'], bg=BG3, fg=ACCENT,
                 font=self.FU, anchor='w', padx=10, pady=8).pack(fill='x')
        rows = [
            ('■ EVIDENCE',           ' · '.join(ev_names),  TEXT2),
            ('⚡ SPEED',              g['speed'],            ACCENT),
            ('🔴 HUNT BEHAVIOUR',     g['hunt'],             '#ff8888'),
            ('⚠  STRENGTH',           g['str_'],             WARN),
            ('✓  WEAKNESS',           g['weak'],             SUCCESS),
            ('◆  HOW TO IDENTIFY',    g['tell'],             PURPLE),
            ('✦  CONFIRMATION TEST',  g['unique'],           '#aabbcc'),
        ]
        for label, val, col in rows:
            f = tk.Frame(container, bg=BG3)
            f.pack(fill='x')
            tk.Label(f, text=label, bg=BG3, fg=TEXT3,
                     font=self.FN_S, anchor='w', padx=10, pady=1).pack(fill='x')
            tk.Label(f, text=val, bg=BG3, fg=col,
                     font=self.FU_S, anchor='w', justify='left',
                     wraplength=370, padx=16, pady=3).pack(fill='x')
            tk.Frame(f, bg=BORDER, height=1).pack(fill='x', padx=10)
        tk.Frame(container, bg=BG3, height=6).pack()

    # ── SPEED pane ────────────────────────────────────────────────────
    def _pane_speed(self):
        outer, inner = self._scrollable(self.pane_host)

        self._sec(inner, 'HOW TO USE THE SPEED TOOL')
        hw = self._card(inner, bg=BG3)
        tk.Label(hw, text=(
            'During a hunt, listen for the ghost\'s FOOTSTEP sounds.\n'
            'Press F10 (or SPACE key) once on each footstep you hear.\n'
            'Tap at least 4 times for an accurate reading — more = better.\n\n'
            'The tool measures time between taps and converts to m/s:\n'
            '  Standard ghost = 1 footstep every ~0.5s = 1.7 m/s\n'
            '  Faster taps = faster ghost   Slower taps = slower ghost\n\n'
            'Works while game is focused — F10 fires globally.\n'
            'Auto-resets after 4 seconds of silence.'
        ), bg=BG3, fg=TEXT2, font=self.FN_S,
           anchor='nw', justify='left', padx=10, pady=8).pack(fill='x')

        self._sec(inner, 'BPM TAP TOOL')
        bpm_box = self._card(inner, bg=BG2)
        self.bpm_lbl = tk.Label(bpm_box, text='—', bg=BG2, fg=ACCENT,
                                 font=('Consolas', 32, 'bold'), pady=6)
        self.bpm_lbl.pack()
        self.bpm_sub = tk.Label(bpm_box, text='BPM  ·  TAP TO START',
                                 bg=BG2, fg=TEXT3, font=self.FN_S)
        self.bpm_sub.pack()
        self.bpm_ms = tk.Label(bpm_box, text=' ', bg=BG2, fg=TEXT2,
                                font=self.FN_S, pady=4)
        self.bpm_ms.pack()

        self.tap_btn = tk.Button(inner,
                                  text='[ TAP FOOTSTEP ]  —  F10 or SPACE',
                                  bg='#0a1828', fg=ACCENT, font=self.FN,
                                  bd=1, relief='flat',
                                  highlightbackground=ACCENT,
                                  highlightthickness=1,
                                  padx=8, pady=12,
                                  activebackground='#1a3050',
                                  cursor='hand2', command=self._tap)
        self.tap_btn.pack(fill='x', padx=8, pady=(4, 2))
        self._btn(inner, 'RESET  (F11)', self._reset_bpm,
                  bg=BG2, fg=TEXT3, border=BORDER, pady=6)

        self._sec(inner, 'LINE OF SIGHT MODIFIER')
        self.los_btn = tk.Button(inner,
                                  text='○  No LOS speedup — click to toggle',
                                  bg=BG2, fg=TEXT2, font=self.FN_S,
                                  bd=1, relief='flat',
                                  highlightbackground=BORDER,
                                  highlightthickness=1,
                                  padx=8, pady=7,
                                  activebackground='#1a0d00',
                                  cursor='hand2', command=self._toggle_los)
        self.los_btn.pack(fill='x', padx=8, pady=2)

        self._sec(inner, 'GHOST SPEED MATCHES')
        self.match_speed = tk.Frame(inner, bg=BG)
        self.match_speed.pack(fill='x', padx=8, pady=(0, 4))
        tk.Label(self.match_speed, text='Tap a beat to see matches...',
                 bg=BG, fg=TEXT3, font=self.FN_S).pack(anchor='w')

        self._sec(inner, 'FULL SPEED REFERENCE')
        for name, mps, col in SPEED_REF:
            row = self._card(inner, bg=BG2)
            tk.Label(row, text=name, bg=BG2, fg=TEXT2,
                     font=self.FU_S, anchor='w', padx=8, pady=3).pack(side='left')
            tk.Label(row, text=f'{mps:.2f} m/s', bg=BG2, fg=col,
                     font=self.FN_S, anchor='e', padx=8).pack(side='right')
        return outer

    def _tap(self):
        self.bpm_taps.append(time.time())
        if len(self.bpm_taps) > 12:
            self.bpm_taps.pop(0)
        self.tap_btn.config(bg='#1a3050')
        self.root.after(120, lambda: self.tap_btn.config(bg='#0a1828'))
        if self.bpm_cancel:
            self.root.after_cancel(self.bpm_cancel)
        self.bpm_cancel = self.root.after(4000, self._reset_bpm)
        self._update_bpm()

    def _update_bpm(self):
        if len(self.bpm_taps) < 2:
            self.bpm_lbl.config(text='—')
            self.bpm_sub.config(text='BPM  ·  TAP TO START')
            self.bpm_ms.config(text=' ')
            return
        intervals = [self.bpm_taps[i] - self.bpm_taps[i-1]
                     for i in range(1, len(self.bpm_taps))]
        avg = sum(intervals) / len(intervals)
        bpm = round(60 / avg)
        mps = round(1.7 * (0.5 / avg), 2)
        self.bpm_lbl.config(text=str(bpm))
        self.bpm_sub.config(text=f'BPM  ·  {len(self.bpm_taps)} taps')
        self.bpm_ms.config(text=f'{round(avg*1000)} ms  ≈  {mps} m/s')
        self._render_speed_matches(mps)

    def _reset_bpm(self):
        self.bpm_taps = []
        if self.bpm_cancel:
            self.root.after_cancel(self.bpm_cancel)
            self.bpm_cancel = None
        self.bpm_lbl.config(text='—')
        self.bpm_sub.config(text='BPM  ·  TAP TO START')
        self.bpm_ms.config(text=' ')
        for w in self.match_speed.winfo_children():
            w.destroy()
        tk.Label(self.match_speed, text='Tap a beat to see matches...',
                 bg=BG, fg=TEXT3, font=self.FN_S).pack(anchor='w')

    def _toggle_los(self):
        self.los = not self.los
        if self.los:
            self.los_btn.config(text='●  LOS speedup ACTIVE  (+~65%)',
                                 fg=WARN, highlightbackground=WARN)
        else:
            self.los_btn.config(text='○  No LOS speedup — click to toggle',
                                 fg=TEXT2, highlightbackground=BORDER)

    def _render_speed_matches(self, mps):
        for w in self.match_speed.winfo_children():
            w.destroy()
        # Tolerance ±0.15 m/s for a match
        candidates = [
            ('Standard (most ghosts)',    1.60, 1.80),
            ('Deogen (near target)',       0.30, 0.50),
            ('Deogen (far)',               2.85, 3.15),
            ('Revenant (no LOS)',          0.90, 1.10),
            ('Revenant (LOS)',             2.85, 3.15),
            ('Thaye (young)',              2.60, 2.90),
            ('Thaye (aged)',               0.85, 1.15),
            ('Jinn (far + power)',         2.35, 2.65),
            ('Hantu (frozen)',             2.55, 2.85),
            ('Raiju (electronics)',        2.35, 2.65),
            ('Moroi (0% sanity)',          2.10, 2.40),
            ('Moroi (100% sanity)',        1.40, 1.60),
            ('Twins — main',               1.80, 2.00),
            ('Twins — decoy',              1.40, 1.60),
            ('Hantu (warm room)',          1.30, 1.50),
        ]
        scored = sorted(
            [(n, lo, hi,
              lo - 0.1 <= mps <= hi + 0.1,
              0.0 if lo - 0.1 <= mps <= hi + 0.1
              else min(abs(mps - lo), abs(mps - hi)))
             for n, lo, hi in candidates],
            key=lambda x: x[4])
        for name, lo, hi, hit, diff in scored[:9]:
            rng = f'{lo:.2f}–{hi:.2f} m/s'
            if hit:
                bg, fg, bord, stat = '#003a1a', SUCCESS, SUCCESS, '✓ MATCH'
            elif diff < 0.3:
                bg, fg, bord, stat = '#1a0d00', WARN,    WARN,    f'~{diff:.2f} off'
            else:
                bg, fg, bord, stat = BG2,       TEXT3,   BORDER,  f'{diff:.2f} off'
            row = tk.Frame(self.match_speed, bg=bg,
                           highlightbackground=bord, highlightthickness=1)
            row.pack(fill='x', pady=1)
            tk.Label(row, text=name, bg=bg, fg=TEXT,
                     font=self.FU_S, anchor='w', padx=8, pady=4).pack(side='left')
            tk.Label(row, text=rng,   bg=bg, fg=TEXT3,
                     font=self.FN_S, padx=4).pack(side='right')
            tk.Label(row, text=stat,  bg=bg, fg=fg,
                     font=self.FN_S, padx=8).pack(side='right')

    # ── MAPS pane ─────────────────────────────────────────────────────
    def _pane_maps(self):
        outer, inner = self._scrollable(self.pane_host)
        self._sec(inner, 'SELECT MAP')
        grid = tk.Frame(inner, bg=BG)
        grid.pack(fill='x', padx=8, pady=(0, 6))
        cols = 3
        self.map_btns = []
        for i, m in enumerate(MAPS):
            short = m['name'].split()[0]
            r, c = divmod(i, cols)
            b = tk.Button(grid, text=short, bg=BG2, fg=TEXT2,
                          font=self.FN_S, bd=1, relief='flat',
                          highlightbackground=BORDER, highlightthickness=1,
                          padx=4, pady=5, cursor='hand2',
                          command=lambda idx=i: self._sel_map(idx))
            b.grid(row=r, column=c, padx=2, pady=2, sticky='ew')
            self.map_btns.append(b)
        for c in range(cols):
            grid.columnconfigure(c, weight=1)
        self.map_card = tk.Frame(inner, bg=BG3,
                                  highlightbackground=BORDER,
                                  highlightthickness=1)
        self.map_card.pack(fill='x', padx=8, pady=(0, 8))
        self._render_map()
        return outer

    def _sel_map(self, idx):
        self.map_idx = idx
        for i, b in enumerate(self.map_btns):
            b.config(fg=(ACCENT if i==idx else TEXT2),
                     bg=('#0a1828' if i==idx else BG2),
                     highlightbackground=(ACCENT if i==idx else BORDER))
        self._render_map()

    def _render_map(self):
        for w in self.map_card.winfo_children():
            w.destroy()
        m = MAPS[self.map_idx]
        bg = BG3
        sc = SUCCESS if m['size']=='Small' else WARN if m['size']=='Medium' else DANGER
        hdr = tk.Frame(self.map_card, bg=bg)
        hdr.pack(fill='x', padx=8, pady=(8, 4))
        tk.Label(hdr, text=m['name'], bg=bg, fg=ACCENT,
                 font=self.FU, anchor='w').pack(side='left')
        tk.Label(hdr, text=f'  [{m["size"].upper()}]', bg=bg,
                 fg=sc, font=self.FN_S).pack(side='left')
        sf = tk.Frame(self.map_card, bg=bg)
        sf.pack(fill='x', padx=8, pady=4)
        for i, (lbl, val) in enumerate([('Floors', str(m['floors'])),
                                         ('Rooms',  m['rooms']),
                                         ('Exits',  str(m['exits']))]):
            c = tk.Frame(sf, bg=BG2, highlightbackground=BORDER,
                         highlightthickness=1)
            c.grid(row=0, column=i, padx=3, sticky='ew')
            tk.Label(c, text=lbl, bg=BG2, fg=TEXT3,
                     font=self.FN_S, padx=8, pady=2).pack()
            tk.Label(c, text=val, bg=BG2, fg=TEXT,
                     font=self.FU_S, padx=8, pady=2).pack()
            sf.columnconfigure(i, weight=1)

        def _kv(label, val, col):
            tk.Label(self.map_card, text=label, bg=bg, fg=TEXT3,
                     font=self.FN_S, anchor='w', padx=8).pack(fill='x', pady=(6, 1))
            tk.Label(self.map_card, text=val, bg=bg, fg=col,
                     font=self.FU_S, anchor='w', justify='left',
                     wraplength=370, padx=16).pack(fill='x', pady=(0, 4))

        _kv('Common ghost rooms:', m['ghost'], WARN)
        _kv('Best hiding spots:', m['hiding'], SUCCESS)
        tk.Frame(self.map_card, bg=BORDER, height=1).pack(
            fill='x', padx=8, pady=6)
        tk.Label(self.map_card, text='STRATEGY TIPS', bg=bg, fg=TEXT3,
                 font=self.FN_S, anchor='w', padx=8).pack(fill='x')
        for tip in m['tips']:
            row = tk.Frame(self.map_card, bg=bg)
            row.pack(fill='x', padx=8, pady=2)
            tk.Label(row, text='›', bg=bg, fg=ACCENT,
                     font=self.FN_S, width=2).pack(side='left', anchor='nw')
            tk.Label(row, text=tip, bg=bg, fg=TEXT2,
                     font=self.FU_S, anchor='nw', justify='left',
                     wraplength=350, padx=4).pack(side='left', fill='x')
        tk.Frame(self.map_card, bg=bg, height=8).pack()

    # ── HUNT pane ─────────────────────────────────────────────────────
    def _pane_hunt(self):
        outer, inner = self._scrollable(self.pane_host)
        self._sec(inner, 'HUNT TIMER  (F1 start/stop)')
        self.hunt_lbl = tk.Label(inner, text='--', bg=BG,
                                  fg=DANGER, font=('Consolas', 30, 'bold'),
                                  pady=4)
        self.hunt_lbl.pack()
        self.hunt_btn_w = self._btn(inner, '▶  START HUNT  (F1)',
                                     self._toggle_hunt,
                                     bg='#1a0000', fg=DANGER,
                                     border=DANGER, pady=10, font=self.FN)
        self._sec(inner, 'SMUDGE TIMER  (F9 = start  ·  F8 = reset)')
        self.smudge_lbl = tk.Label(inner, text='--', bg=BG,
                                    fg=WARN, font=('Consolas', 20, 'bold'),
                                    pady=2)
        self.smudge_lbl.pack()
        self.smudge_btn_w = self._btn(inner, '🕯  SMUDGE USED  (90 seconds)',
                                       self._start_smudge,
                                       bg='#1a0800', fg=WARN,
                                       border=WARN, pady=9, font=self.FN)
        self._sec(inner, 'TEAM SANITY')
        san_explain = self._card(inner, bg='#0a1020', border=BORDER)
        san_text = (
            "Track your team's sanity here manually.\n"
            "Drag sliders to update each player as the game goes on.\n\n"
            "Why sanity matters:\n"
            "  * Most ghosts hunt below 50% sanity\n"
            "  * Demon hunts at ANY sanity, even 100%\n"
            "  * Shade won't hunt above 35% (but can surprise early)\n"
            "  * Dark rooms drain ~2% per minute per player\n"
            "  * Sanity pills restore 40% -- use them before hunts\n\n"
            "Tip: outdoor areas do NOT drain sanity.\n"
            "Stay outside between evidence runs to stay safe."
        )
        tk.Label(san_explain, text=san_text, bg='#0a1020', fg=TEXT2,
                 font=self.FN_S, anchor='nw', justify='left',
                 padx=10, pady=8).pack(fill='x')
        self.san_frame = tk.Frame(inner, bg=BG)
        self.san_frame.pack(fill='x', padx=8, pady=(0, 4))
        self._render_sanity()
        tip = self._card(inner, bg=BG3, border=ACCENT)
        tk.Label(tip, text=(
            'Hunt thresholds:\n'
            '>70% — Safe\n'
            '>50% — Most ghosts can hunt\n'
            '>40% — Standard threshold\n'
            'Any% — Demon (hunts immediately!)'
        ), bg=BG3, fg=TEXT2, font=self.FN_S,
           anchor='w', justify='left', padx=8, pady=8).pack(fill='x')
        return outer

    def _render_sanity(self):
        for w in self.san_frame.winfo_children():
            w.destroy()
        pcols = [ACCENT, '#ff8844', SUCCESS, PURPLE]
        for i in range(4):
            v = self.sanity[i]
            bc = SUCCESS if v > 70 else WARN if v > 40 else DANGER
            row = tk.Frame(self.san_frame, bg=BG)
            row.pack(fill='x', pady=2)
            tk.Label(row, text=f'P{i+1}', bg=BG, fg=TEXT2,
                     font=self.FN_S, width=3).pack(side='left')
            bar_o = tk.Frame(row, bg=BG2, highlightbackground=BORDER,
                             highlightthickness=1, height=10)
            bar_o.pack(side='left', fill='x', expand=True, padx=4, pady=6)
            bar_o.pack_propagate(False)
            tk.Frame(bar_o, bg=bc).place(x=0, y=0, relwidth=v/100, height=10)
            tk.Label(row, text=f'{v}%', bg=BG, fg=TEXT2,
                     font=self.FN_S, width=5).pack(side='left')
            var = tk.IntVar(value=v)
            tk.Scale(row, from_=0, to=100, orient='horizontal',
                     variable=var, bg=BG, fg=pcols[i],
                     troughcolor=BG2, highlightthickness=0,
                     bd=0, length=75, showvalue=False,
                     command=lambda val, idx=i: self._set_san(idx, int(val))
                     ).pack(side='left', padx=4)

    def _set_san(self, i, v):
        self.sanity[i] = v
        self._render_sanity()

    def _toggle_hunt(self):
        if self.hunt_active:
            self.hunt_active = False
            self.hunt_btn_w.config(text='▶  START HUNT  (F1)', bg='#1a0000')
            self.hunt_lbl.config(fg=SUCCESS)
        else:
            self.hunt_active = True
            self.hunt_start = time.time()
            self.hunt_btn_w.config(text='■  HUNTING...', bg='#2a0000')
            self.hunt_lbl.config(fg=DANGER)

    def _start_smudge(self):
        if self.smudge_active:
            return
        self.smudge_active = True
        self.smudge_start = time.time()
        self.smudge_btn_w.config(state='disabled', bg='#0a0800')

    def _stop_smudge(self):
        self.smudge_active = False
        self.smudge_lbl.config(text='--', fg=WARN)
        self.smudge_btn_w.config(state='normal', bg='#1a0800')

    # ── NOTES pane ────────────────────────────────────────────────────
    def _pane_notes(self):
        outer, inner = self._scrollable(self.pane_host)
        self._sec(inner, 'INVESTIGATION LOG')
        self.notes = tk.Text(inner, bg=BG3, fg=TEXT,
                              font=self.FN_S, bd=1, relief='flat',
                              highlightbackground=BORDER, highlightthickness=1,
                              insertbackground=ACCENT,
                              padx=8, pady=8, height=20, wrap='word')
        self.notes.pack(fill='both', padx=8, pady=(0, 4))
        self.notes.insert('1.0',
            '// Ghost room: \n// Temperature: \n'
            '// Behaviour: \n// Ghost suspect: \n// Notes: \n')
        def _clear():
            self.notes.delete('1.0', 'end')
            self.notes.insert('1.0',
                '// Ghost room: \n// Temperature: \n'
                '// Behaviour: \n// Ghost suspect: \n// Notes: \n')
        self._btn(inner, 'CLEAR NOTES', _clear,
                  bg=BG2, fg=TEXT3, border=BORDER)
        return outer

    # ── tab switching ─────────────────────────────────────────────────
    def _switch(self, tab):
        self.tab = tab
        for pane in self.panes.values():
            pane.pack_forget()
        self.panes[tab].pack(fill='both', expand=True)
        for tid, btn in self.tab_btns.items():
            btn.config(fg=(ACCENT if tid==tab else MUTED),
                       bg=('#0a1828' if tid==tab else '#060e18'))
        # bind mousewheel to all widgets inside this pane after it's packed
        self.root.after(50, lambda: self._bind_scroll_all(self.panes[tab]))

    def _bind_scroll_all(self, pane):
        """Bind mousewheel to every widget inside a scrollable pane."""
        canvas = getattr(pane, '_canvas', None)
        wheel  = getattr(pane, '_wheel',  None)
        if canvas and wheel:
            self._bind_scroll_recursive(pane, wheel)

    def _bind_scroll_recursive(self, widget, handler):
        widget.bind('<MouseWheel>', handler)
        for child in widget.winfo_children():
            self._bind_scroll_recursive(child, handler)

    # ── logic ─────────────────────────────────────────────────────────
    def _possible(self):
        found = [k for k, v in self.ev.items() if v == 'found']
        ruled = [k for k, v in self.ev.items() if v == 'ruled']
        return [g for g in GHOSTS
                if all(f in g['ev'] for f in found)
                and not any(r in g['ev'] for r in ruled)]

    def _refresh(self):
        poss = self._possible()
        self._render_ev_grid()
        for w in self.match_frame.winfo_children():
            w.destroy()
        if not poss:
            tk.Label(self.match_frame,
                     text='✗  NO MATCH — recheck evidence',
                     bg=BG, fg=DANGER, font=self.FN_S,
                     padx=6, pady=6, anchor='w').pack(fill='x')
        else:
            self._render_ev_ghost_list(self.match_frame, poss)
        self._update_ghost_list_styles(poss)
        found_n = sum(1 for v in self.ev.values() if v == 'found')
        top = (f'→ {poss[0]["name"].upper()}' if len(poss) == 1
               else 'NO MATCH' if not poss else '—')
        self.sb_lbl.config(
            text=f'● LIVE  |  MATCHES: {len(poss)}  |  EV: {found_n}/7  |  {top}')
        # rebind scroll for freshly rendered widgets
        self.root.after(50, lambda: self._bind_scroll_all(self.panes[self.tab]))

    # ── timers ────────────────────────────────────────────────────────
    def _tick(self):
        if self.hunt_active:
            self.hunt_lbl.config(text=f'{time.time()-self.hunt_start:.1f}s')
        if self.smudge_active:
            rem = max(0, 90 - (time.time() - self.smudge_start))
            self.smudge_lbl.config(text=f'{int(rem)}s',
                                    fg=SUCCESS if rem < 10 else WARN)
            if rem <= 0:
                self.smudge_active = False
                self.smudge_lbl.config(text='READY', fg=SUCCESS)
                self.smudge_btn_w.config(state='normal', bg='#1a0800')
                self.root.after(3000, lambda: self.smudge_lbl.config(
                    text='--', fg=WARN))
        self.root.after(100, self._tick)

    # ── global hotkeys ────────────────────────────────────────────────
    def _start_global_hotkeys(self):
        """
        Run the keyboard hotkey listener in a daemon thread so it fires
        even when Phasmophobia is the foreground window.
        """
        def _listen():
            try:
                import keyboard

                # All hotkeys use F-keys and Alt+number — safe, no conflict with WASD
                KEY_ACTIONS = {
                    'f1':           self._toggle_hunt,
                    'f8':           self._stop_smudge,
                    'f9':           self._start_smudge,
                    'f10':          self._tap,
                    'f11':          self._reset_bpm,
                    'home':         self._compact,
                    'scroll lock':  self._cycle_op,
                }

                def on_key(event):
                    name = (event.name or '').lower()
                    if name in KEY_ACTIONS:
                        self.root.after(0, KEY_ACTIONS[name])
                        return
                    # Alt+1..7 evidence cycle, Alt+0 reset
                    try:
                        if keyboard.is_pressed('alt'):
                            if name.isdigit() and 1 <= int(name) <= 7:
                                eid = EVIDENCE[int(name) - 1][0]
                                self.root.after(0, lambda k=eid: self._ev_cycle(k))
                            elif name == '0':
                                self.root.after(0, self._reset_all)
                    except Exception:
                        pass

                # suppress=False is critical: game still receives ALL its inputs
                # WASD, mouse, spacebar, etc. are completely unaffected
                keyboard.on_press(on_key, suppress=False)
                keyboard.wait()
            except ImportError:
                # Fall back to tkinter bindings (window must be focused)
                self.root.bind('<F10>',   lambda e: self._tap())
                self.root.bind('<F11>',   lambda e: self._reset_bpm())
                self.root.bind('<F1>',    lambda e: self._toggle_hunt())
                self.root.bind('<F9>',    lambda e: self._start_smudge())
                self.root.bind('<F8>',    lambda e: self._stop_smudge())
                self.root.bind('<Home>',  lambda e: self._compact())
                self.root.bind('<space>', lambda e: self._tap())
                print('[WARN] "keyboard" library not found.')
                print('[WARN] Hotkeys only work when overlay window is focused.')
                print('[WARN] To enable global hotkeys run:  pip install keyboard')

        t = threading.Thread(target=_listen, daemon=True)
        t.start()

    # ── misc controls ─────────────────────────────────────────────────
    def _cycle_op(self):
        self.op_idx = (self.op_idx + 1) % len(self.opacities)
        self.root.attributes('-alpha', self.opacities[self.op_idx])

    def _compact(self):
        geo = self.root.geometry()
        w, h = map(int, geo.split('+')[0].split('x'))
        self.root.geometry('430x56' if h > 100 else '430x720')


    # ── persist path ─────────────────────────────────────────────────
    def _journal_path(self):
        """Use APPDATA so it works inside PyInstaller --onefile exe.
        PyInstaller extracts to a read-only temp folder; APPDATA persists.
        """
        base = os.path.join(
            os.environ.get('APPDATA', os.path.expanduser('~')),
            'PhasmoJournal'
        )
        os.makedirs(base, exist_ok=True)
        return os.path.join(base, 'phasmo_rounds.json')

    def _load_rounds(self):
        try:
            with open(self._journal_path(), 'r', encoding='utf-8') as f:
                self.rounds = json.load(f)
        except Exception:
            self.rounds = []

    def _save_rounds_to_disk(self):
        try:
            with open(self._journal_path(), 'w', encoding='utf-8') as f:
                json.dump(self.rounds, f, indent=2, ensure_ascii=False)
        except Exception as ex:
            print(f'[WARN] Could not save rounds: {ex}')

    def _save_round(self):
        name = getattr(self, 'round_name_var', None)
        name = name.get().strip() if name else ''
        if not name or name == 'Round name...':
            name = 'Unnamed round'
        poss = self._possible()
        found_ev = [lbl for k, lbl in EVIDENCE if self.ev[k] == 'found']
        ruled_ev = [lbl for k, lbl in EVIDENCE if self.ev[k] == 'ruled']
        round_data = {
            'id':        int(time.time()),
            'name':      name,
            'date':      datetime.now().strftime('%Y-%m-%d %H:%M'),
            'suspect':   self.ev_suspect or '',
            'eliminated': list(self.ev_eliminated),
            'found_ev':  found_ev,
            'ruled_ev':  ruled_ev,
            'possible':  [g['name'] for g in poss],
            'map':       MAPS[self.map_idx]['name'],
            'notes':     self.notes.get('1.0', 'end').strip() if hasattr(self, 'notes') else '',
            'bpm_mps':   self.bpm_ms.cget('text') if hasattr(self, 'bpm_ms') else '',
            'sanity':    list(self.sanity),
        }
        self.rounds.insert(0, round_data)
        self._save_rounds_to_disk()
        # Clear name field
        if hasattr(self, 'round_name_var'):
            self.round_name_var.set('Round name...')
        # Switch to journal to see it
        self._render_journal_list()
        self._switch('journal')

    def _delete_round(self, rid):
        self.rounds = [r for r in self.rounds if r['id'] != rid]
        self._save_rounds_to_disk()
        self._render_journal_list()

    # ── JOURNAL pane ──────────────────────────────────────────────────
    def _pane_journal(self):
        outer, inner = self._scrollable(self.pane_host)

        self._sec(inner, 'SAVED ROUNDS')

        # Search bar
        search_row = tk.Frame(inner, bg=BG)
        search_row.pack(fill='x', padx=8, pady=(0, 4))
        self.journal_filter_var = tk.StringVar()
        search_entry = tk.Entry(search_row, textvariable=self.journal_filter_var,
                                bg=BG2, fg=TEXT, font=self.FN_S,
                                insertbackground=ACCENT,
                                highlightbackground=BORDER, highlightthickness=1,
                                relief='flat', bd=0)
        search_entry.pack(fill='x', ipady=6)
        search_entry.insert(0, 'Filter by name, ghost, map...')
        search_entry.bind('<FocusIn>',
            lambda e: search_entry.delete(0,'end')
            if search_entry.get() == 'Filter by name, ghost, map...' else None)
        self.journal_filter_var.trace_add('write',
            lambda *a: self._render_journal_list())

        # Round list container
        self.journal_list_frame = tk.Frame(inner, bg=BG)
        self.journal_list_frame.pack(fill='x', padx=8, pady=(0, 4))

        # Detail panel
        self._sec(inner, 'ROUND DETAIL')
        self.journal_detail = tk.Frame(inner, bg=BG3,
                                        highlightbackground=BORDER,
                                        highlightthickness=1)
        self.journal_detail.pack(fill='x', padx=8, pady=(0, 8))
        tk.Label(self.journal_detail,
                 text='Select a round above to see full details',
                 bg=BG3, fg=TEXT3, font=self.FU_S,
                 anchor='w', padx=8, pady=8).pack(fill='x')

        self._render_journal_list()
        return outer

    def _render_journal_list(self):
        if not hasattr(self, 'journal_list_frame'):
            return
        for w in self.journal_list_frame.winfo_children():
            w.destroy()
        filt = self.journal_filter_var.get().lower() if hasattr(self, 'journal_filter_var') else ''
        if filt in ('', 'filter by name, ghost, map...'):
            filt = ''
        rounds = self.rounds
        if filt:
            rounds = [r for r in rounds if
                      filt in r.get('name','').lower() or
                      filt in r.get('suspect','').lower() or
                      filt in r.get('map','').lower() or
                      any(filt in g.lower() for g in r.get('possible',[])) or
                      filt in r.get('notes','').lower()]
        if not rounds:
            tk.Label(self.journal_list_frame,
                     text='No saved rounds yet — complete an investigation and press SAVE +',
                     bg=BG, fg=TEXT3, font=self.FN_S,
                     wraplength=360, anchor='w', padx=4, pady=8).pack(fill='x')
            return
        for r in rounds:
            row = tk.Frame(self.journal_list_frame, bg=BG2,
                           highlightbackground=BORDER, highlightthickness=1)
            row.pack(fill='x', pady=2)
            # Top line: name + date
            top = tk.Frame(row, bg=BG2)
            top.pack(fill='x', padx=8, pady=(5,1))
            tk.Label(top, text=r.get('name','?'), bg=BG2, fg=TEXT,
                     font=self.FU_S, anchor='w').pack(side='left')
            tk.Label(top, text=r.get('date',''), bg=BG2, fg=TEXT3,
                     font=self.FN_S, anchor='e').pack(side='right')
            # Second line: suspect + map + ev count
            bot = tk.Frame(row, bg=BG2)
            bot.pack(fill='x', padx=8, pady=(0,5))
            suspect_txt = r.get('suspect','?') or '?'
            map_txt = r.get('map','?').split()[0]
            ev_count = len(r.get('found_ev',[]))
            info = f"Ghost: {suspect_txt}   Map: {map_txt}   Evidence: {ev_count}/7"
            tk.Label(bot, text=info, bg=BG2,
                     fg=(WARN if r.get('suspect') else TEXT2),
                     font=self.FN_S, anchor='w').pack(side='left')
            # Delete button
            del_btn = tk.Button(bot, text='✕', bg=BG2, fg='#553333',
                                font=self.FN_S, bd=0, padx=6,
                                cursor='hand2',
                                activebackground='#2a0000',
                                activeforeground=DANGER,
                                command=lambda rid=r['id']: self._delete_round(rid))
            del_btn.pack(side='right')
            # Click row to expand detail
            for w in [row, top, bot]:
                w.bind('<Button-1>', lambda e, rd=r: self._show_round_detail(rd))

    def _show_round_detail(self, r):
        if not hasattr(self, 'journal_detail'):
            return
        for w in self.journal_detail.winfo_children():
            w.destroy()
        bg = BG3

        def row(label, val, col=TEXT2):
            f = tk.Frame(self.journal_detail, bg=bg)
            f.pack(fill='x')
            tk.Label(f, text=label, bg=bg, fg=TEXT3,
                     font=self.FN_S, anchor='w', padx=10, pady=1).pack(fill='x')
            tk.Label(f, text=val or '—', bg=bg, fg=col,
                     font=self.FU_S, anchor='w', justify='left',
                     wraplength=370, padx=16, pady=2).pack(fill='x')
            tk.Frame(f, bg=BORDER, height=1).pack(fill='x', padx=10)

        tk.Label(self.journal_detail,
                 text=r.get('name','?'), bg=bg, fg=ACCENT,
                 font=self.FU, anchor='w', padx=10, pady=8).pack(fill='x')
        row('Date', r.get('date',''))
        row('Map', r.get('map',''), WARN)
        row('Ghost suspect', r.get('suspect','') or 'Not set', WARN)
        row('Evidence found', ', '.join(r.get('found_ev',[])) or 'None', SUCCESS)
        row('Evidence ruled out', ', '.join(r.get('ruled_ev',[])) or 'None', DANGER)
        row('Possible ghosts', ', '.join(r.get('possible',[])) or 'None', TEXT2)
        row('Eliminated ghosts', ', '.join(r.get('eliminated',[])) or 'None', '#553333')
        row('Speed reading', r.get('bpm_mps','') or 'Not recorded', ACCENT)
        san = r.get('sanity',[75,75,75,75])
        row('Team sanity at save', f"P1:{san[0]}%  P2:{san[1]}%  P3:{san[2]}%  P4:{san[3]}%", TEXT2)
        row('Notes', r.get('notes','') or 'No notes', TEXT2)
        tk.Frame(self.journal_detail, bg=bg, height=6).pack()

    def _reset_all(self):
        for k in self.ev:
            self.ev[k] = None
        self.sel_ghost     = None
        self.ev_suspect    = None
        self.ev_eliminated = set()
        self.hunt_active   = False
        self._reset_bpm()
        self._refresh()
        if hasattr(self, "journal_detail"):
            self._render_journal_list()

    def run(self):
        self._sel_map(0)
        self._refresh()
        self.root.mainloop()


if __name__ == '__main__':
    App().run()
