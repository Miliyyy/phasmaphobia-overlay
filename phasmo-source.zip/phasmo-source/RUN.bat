@echo off
setlocal

:: ── Find pythonw (no terminal window) ──────────────────────────────
set PYW=

:: Try pythonw on PATH first
where pythonw >nul 2>&1 && set PYW=pythonw

:: If not found, search common install locations
if "%PYW%"=="" (
    for %%P in (
        "%LOCALAPPDATA%\Programs\Python\Python313\pythonw.exe"
        "%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe"
        "%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe"
        "%LOCALAPPDATA%\Programs\Python\Python310\pythonw.exe"
        "C:\Python313\pythonw.exe"
        "C:\Python312\pythonw.exe"
        "C:\Python311\pythonw.exe"
        "C:\Python310\pythonw.exe"
        "C:\Program Files\Python313\pythonw.exe"
        "C:\Program Files\Python312\pythonw.exe"
    ) do (
        if exist %%P set PYW=%%P
    )
)

if "%PYW%"=="" (
    echo.
    echo  [ERROR] Python not found on this computer.
    echo.
    echo  Please install Python 3.10 or newer:
    echo  https://www.python.org/downloads/
    echo.
    echo  During install, CHECK the box: "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

:: ── Install keyboard library silently if missing ────────────────────
%PYW% -c "import keyboard" >nul 2>&1
if errorlevel 1 (
    echo Installing keyboard library (one time only)...
    python -m pip install keyboard --quiet >nul 2>&1
)

:: ── Launch overlay — no terminal window ────────────────────────────
start "" %PYW% "%~dp0phasmo_journal.pyw"
exit /b 0
