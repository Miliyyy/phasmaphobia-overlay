#define AppName "Phasmo Journal"
#define AppVersion "1.0.0"
#define AppPublisher "Miliyyy"
#define AppURL "https://github.com/Miliyyy/phasmo-journal"
#define AppExeName "PhasmoJournal.exe"

[Setup]
AppId={{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
AppPublisherURL={#AppURL}
AppSupportURL={#AppURL}/issues
AppUpdatesURL={#AppURL}/releases
DefaultDirName={autopf}\PhasmoJournal
DefaultGroupName={#AppName}
AllowNoIcons=yes
OutputDir=installer_output
OutputBaseFilename=PhasmoJournal_Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\{#AppExeName}
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog

[Messages]
; Welcome page text
WelcomeLabel1=Welcome to {#AppName} Setup
WelcomeLabel2=This will install {#AppName} version {#AppVersion} on your computer.%n%nCreated by {#AppPublisher}.%n%nClick Next to continue.

; Finish page text  
FinishedHeadingLabel=Completing {#AppName} Setup
FinishedLabel={#AppName} has been installed on your computer.%n%nCreated by {#AppPublisher}.%n%nClick Finish to close Setup.

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional icons:"
Name: "startupicon"; Description: "Launch Phasmo Journal when Windows starts"; GroupDescription: "Startup:"; Flags: unchecked

[Files]
Source: "PhasmoJournal.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExeName}"
Name: "{group}\Uninstall {#AppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExeName}"; Tasks: desktopicon
Name: "{userstartup}\{#AppName}"; Filename: "{app}\{#AppExeName}"; Tasks: startupicon

[Run]
Filename: "{app}\{#AppExeName}"; Description: "Launch {#AppName} now"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Uncomment below to delete saved rounds on uninstall (not recommended)
; Type: files; Name: "{userappdata}\PhasmoJournal\phasmo_rounds.json"
; Type: dirifempty; Name: "{userappdata}\PhasmoJournal"

[Code]
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
  begin
    MsgBox(
      'Phasmo Journal has been uninstalled.' + #13#10 + #13#10 +
      'Your saved investigation rounds are kept at:' + #13#10 +
      ExpandConstant('{userappdata}') + '\PhasmoJournal\phasmo_rounds.json' + #13#10 + #13#10 +
      'Delete that folder manually if you want to remove them.',
      mbInformation, MB_OK);
  end;
end;
